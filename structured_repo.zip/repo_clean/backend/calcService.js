export function calculate(input) {
return {
input,
result: 0
};
}