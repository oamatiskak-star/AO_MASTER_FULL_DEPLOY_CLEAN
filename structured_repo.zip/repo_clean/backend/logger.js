const logger = {
log: (...args) => console.log("[LOG]", ...args),
error: (...args) => console.error("[ERROR]", ...args)
};

export default logger;