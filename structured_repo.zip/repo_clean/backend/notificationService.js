export function notify(type, payload) {
return {
sent: true,
type,
payload
};
}