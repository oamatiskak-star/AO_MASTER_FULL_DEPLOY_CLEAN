export async function GET() {
  return Response.json({ ok: true, msg: "Frontend API live" })
}
