export const Commands = {
  START: "start",
  STATUS: "status",
  EXECUTE: "execute"
}
