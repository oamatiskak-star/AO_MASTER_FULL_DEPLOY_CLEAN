export default function ModulesLayout({ children }) {
return (
<div style={{ padding: 40 }}>
{children}
</div>
);
}