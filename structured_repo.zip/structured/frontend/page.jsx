export default function Login() {
  return (
    <div style={{ padding: 40 }}>
      <h1>Login</h1>
      <p>Login werkt.</p>
    </div>
  );
}
