export default function Dashboard(){ return (<div style={{padding:20}}><h1>Dashboard</h1><p>AO SaaS actief.</p></div>) }
